public class Solution{
    //ESTA CLASE NO TIENE MAIN
    
    
    public static int [] reporte(int [] compra){
        //EN ESTE ESPACIO PONER SU LÓGICA
        int salida[]={0,0,0};
        int suma=0;
        for(int i=0; i<compra.length;i++){
            suma+=compra[i];
        }
        
        int mayor, menor;
        mayor = menor = compra [0];
        
        //Producto mas barato
       
        for(int k=0; k<compra.length;k++){
            if(compra[k]<menor){
                menor=compra[k];
            }
        }
        
        //Producto mas caro
        for(int k=0; k<compra.length;k++){
            if(compra[k]>mayor){
                mayor=compra[k];
            }
        }
        
        for(int j=0; j<salida.length;j++){
            salida[0]=suma;
            salida[2]=mayor;
            salida[1]=menor;
        }

        
        
        
        return salida;
        
        
        
    }
}